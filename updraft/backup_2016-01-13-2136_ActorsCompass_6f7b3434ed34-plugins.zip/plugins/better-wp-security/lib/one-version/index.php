<?php
require( dirname( __FILE__ ) . '/class-itsec-one-version.php' ); //Only have one version of the plugin
new ITSEC_One_Version();